﻿using System.Collections.Generic;
using UnityEngine;
/// Sukuria objektus ir pasuka tam tikru kampu
public class MultipleObjects : MonoBehaviour {

    public CombineMeshes combineMeshes;
    /// <summary>
    /// Yra sukuriama pradinė objektų pora
    /// </summary>
    /// <param name="original"></param> Kopijavimų skaičius
    /// <param name="curveStrength"></param> Posūkio kampas
    /// <param name="objectsTimesTwo"></param> Imamos iškart po dvi figūros.
    /// <returns></returns>
    public GameObject MultiplyObjects(GameObject original, int curveStrength, int objectsTimesTwo)
    { 
        float rotationStep = 180;

        List<GameObject> objList = new List<GameObject> { original };

        objList = CreateNewObjs(1, original, rotationStep, objList); // Sukuria pradine objektu pora

        objList[0].transform.position += new Vector3(-curveStrength, 0, 0);
        objList[1].transform.position += new Vector3(curveStrength, 0, 0);

        GameObject mergedMesh = combineMeshes.CombineOBJ(objList);
        mergedMesh.transform.position = Vector3.zero;
        objList.Clear();

        rotationStep = 360 / (objectsTimesTwo*2);
        /// <summary></summary>
        /// Porų sūkinėjimas plokštumoje
        /// <summary></summary>
        objList = CreateNewObjs(objectsTimesTwo, mergedMesh, rotationStep, objList); 
        DestroyImmediate(mergedMesh);
        return combineMeshes.CombineOBJ(objList);
    }
    /// <summary>
    /// 
    /// </summary>
    /// <param name="count"></param> Gijų kiekis
    /// <param name="original"></param> Parametras kuris gauną gijų porą arba vieną giją ir kopijuoją pagal nurodytą kiekį
    /// <param name="rotationStep"></param> Kampas tarp objektų
    /// <param name="objList"></param> Objektų sąrašas
    /// <returns></returns>
    /// <summary></summary>
    /// Gaunamas objektų kiekis tipas ir sąrašas į kurį bus talpinamas objektas
    /// <summary></summary>
    List<GameObject> CreateNewObjs(int count, GameObject original,float rotationStep,List<GameObject> objList ) 
    { 
        float currStep = 0;
        for (int i = 0; i < count; i++)
        {
            GameObject newObj = Instantiate(original, original.transform.position, original.transform.rotation);
            newObj.transform.rotation = Quaternion.Euler(0, currStep += rotationStep, 0);
            objList.Add(newObj);
        }

        return objList;
    }


}
