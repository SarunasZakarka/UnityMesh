var indexSectionsWithContent =
{
  0: "abcgmstv",
  1: "acmv",
  2: "abcgmst"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Functions"
};

