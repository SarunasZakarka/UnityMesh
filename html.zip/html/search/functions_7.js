var searchData=
[
  ['vertex',['Vertex',['../struct_vertex.html#a471c586bf72d6252196c9b3b01b6c0e7',1,'Vertex']]]
];
